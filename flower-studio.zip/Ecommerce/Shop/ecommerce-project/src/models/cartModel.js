const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema({
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Product'
    },
    quantity: {
        type: Number,
        required: true,
        min: 1
    }
});

const cartSchema = new mongoose.Schema({
    items: [cartItemSchema],
    totalPrice: {
        type: Number,
        default: 0
    }
});

cartSchema.methods.addItem = function(productId, quantity) {
    const existingItemIndex = this.items.findIndex(item => item.productId.toString() === productId.toString());
    
    if (existingItemIndex > -1) {
        this.items[existingItemIndex].quantity += quantity;
    } else {
        this.items.push({ productId, quantity });
    }
    
    this.calculateTotal();
};

cartSchema.methods.removeItem = function(productId) {
    this.items = this.items.filter(item => item.productId.toString() !== productId.toString());
    this.calculateTotal();
};

cartSchema.methods.calculateTotal = function() {
    this.totalPrice = this.items.reduce((total, item) => {
        return total + (item.quantity * item.price); // Assuming price is available in item
    }, 0);
};

const Cart = mongoose.model('Cart', cartSchema);

module.exports = Cart;