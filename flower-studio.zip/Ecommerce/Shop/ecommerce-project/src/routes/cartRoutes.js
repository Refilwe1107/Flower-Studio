const express = require('express');
const router = express.Router();
const CartController = require('../controllers/cartController');

const cartController = new CartController();

router.post('/add', cartController.addItem);
router.post('/remove', cartController.removeItem);
router.get('/', cartController.viewCart);
router.post('/update', cartController.updateItemQuantity);

module.exports = router;