class CartController {
    constructor() {
        this.cart = [];
    }

    addItem(product) {
        const existingItem = this.cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += product.quantity;
        } else {
            this.cart.push({ ...product, quantity: product.quantity });
        }
    }

    removeItem(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
    }

    updateQuantity(productId, quantity) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            item.quantity = quantity;
        }
    }

    getCartItems() {
        return this.cart;
    }

    calculateTotal() {
        return this.cart.reduce((total, item) => total + item.price * item.quantity, 0);
    }

    clearCart() {
        this.cart = [];
    }
}

export default new CartController();